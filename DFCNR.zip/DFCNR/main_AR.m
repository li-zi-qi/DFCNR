clear
clc

load('data/AR.mat');

%--------------------------------------------------------------------------

Tr_DAT = double(NewTrain_DAT);
trls = trainlabels;
Tt_DAT = double(NewTest_DAT);
ttls = testlabels;

train_tol = size(Tr_DAT, 2);
test_tol = size(Tt_DAT, 2);

%-------------------------------------------------------------------------

% dim = 54, lambda1 = 0.001000, lambda2 = 0.001000, mu = 0.100000, acc = 85.41
% dim = 120, lambda1 = 0.000100, lambda2 = 0.000100, mu = 0.100000, acc = 91.27
% dim = 300, lambda1 = 0.001000, lambda2 = 0.010000, mu = 0.010000, acc = 94.71

lambda1 = 0.001000;
lambda2 = 0.001000;
mu = 0.100000;

param.lambda1 = lambda1;
param.lambda2 = lambda2;
param.mu = mu;

param.maxIter = 5;

%--------------------------------------------------------------------------

dim = 54;

[disc_set, disc_value, Mean_Image]  =  Eigenface_f(Tr_DAT, dim);
tr_dat = disc_set' * Tr_DAT;
tt_dat = disc_set' * Tt_DAT;
tr_dat = normc(tr_dat);
tt_dat = normc(tt_dat);

X = tr_dat;
id = zeros(1, test_tol);

class_num = length(unique(trls));
[m, n] = size(X);

M = zeros(m, class_num);
sumXibaTXiba = zeros(n);
temp = zeros(n);

for ci = 1:class_num
	index = trls == ci;
	M(:, ci) = mean(X(:, index), 2);
	Xiba = zeros(m, n);
	Xiba(:, index) = X(:, index);
	
	sumXibaTXiba = sumXibaTXiba + (Xiba' * Xiba);
	temp = temp + (X - Xiba)' * (X - Xiba);
end

P =  (X' * X + lambda1 * sumXibaTXiba + lambda2 * temp + 0.5 * mu * eye(n)) \ eye(n);

param.P = P;
param.M = M;

parfor i = 1:test_tol

	y = tt_dat(:, i);

	alpha = DFCNR(X, y, param, trls);

	residuals = residual(X, y, alpha, trls);

	[~, index] = min(residuals);

	id(i) = index;
end

cornum = sum(id == ttls);
acc = cornum / length(ttls);

fprintf('dim = %d, lambda1 = %f, lambda2 = %f, mu = %f, acc = %.2f\n', dim, param.lambda1, param.lambda2, param.mu, acc * 100);