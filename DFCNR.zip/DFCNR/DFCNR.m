function alpha = DFCNR(X, y, param, trls)

    lambda1 = param.lambda1;
    lambda2 = param.lambda2;
    mu = param.mu;
    maxIter = param.maxIter;
    
    M = param.M;
    P = param.P;
    
    class_num = length(unique(trls));
    [m, n] = size(X);
    
    alpha = zeros(n, 1);
    F1 = zeros(m, class_num);
    F2 = zeros(m, class_num);
    z = alpha;
    delta = alpha;
    
    XTy = X' * y;
    
    iter = 0;
    while iter < maxIter
        
        iter = iter + 1;

        temp = zeros(n, 1);
        for ci = 1:class_num
            index = trls == ci;
            Xiba = zeros(m, n);
            Xiba(:, index) = X(:, index);

            temp = temp + lambda1 * Xiba' * (M(:, ci) - F1(:, ci)) + lambda2 * (X - Xiba)' * F2(:, ci);
        end
        
        alpha = P * (XTy + temp + 0.5 * mu * z + 0.5 * delta);

        for ci = 1:class_num
            index = trls == ci;
            F1(:, ci) = M(:, ci) - X(:, index) * alpha(index);
            F2(:, ci) = X * alpha - X(:, index) * alpha(index);
        end

        z = max(0, alpha - delta / mu);
        delta = delta + mu * (z - alpha);
    end
end
